# Usage Guide

## Choose a scale

- `PNG_2X`: authored component dimensions for high-density or larger UI layouts
- `PNG_1X`: exact half-size convenience exports

## Nine-slice use

Read `NINE_SLICE.json`. The left, top, right, and bottom values define protected border regions. Stretch only the center and straight edge regions according to the target engine's nine-slice controls.

## Resource bars

Each resource-bar fill uses the same canvas dimensions as its matching frame. Place the fill first, then place the frame at exactly the same position. Crop or mask the fill in-engine when continuous values are required.

## Typography and localization

Fonts and labels are intentionally excluded. Add localized text inside the clear component centers and verify padding at the longest supported language strings.

## Accessibility

Do not rely only on red, blue, green, or purple color. Pair resource bars and states with labels, icons, patterns, or accessible game logic. Verify contrast, focus indication, controller navigation, touch target sizes, and text scaling in the actual project.

## Compatibility

The package contains engine-agnostic PNG and JSON files. No engine importer, responsive layout behavior, input logic, or runtime code is included.
