# Dark Fantasy Modular Combat HUD — Free 12 Component Sampler

Version: v1.0

## Included

- 12 unique transparent UI components
- Authored 2x PNG files and exact half-size 1x exports
- Text-free and icon-free customer components
- Catalog CSV and JSON
- Nine-slice metadata for scalable elements
- Design-token JSON
- Browser component gallery
- Engine-agnostic usage guide
- Single-Entity Commercial Asset License v1.0
- AI-assisted production disclosure

## Format statement

This is a raster PNG and JSON component library. It is not an SVG, PSD, font, source-code, Unity, Godot, Unreal, or RPG Maker package.

The nine-slice JSON provides recommended margins. It is not an engine importer and must be translated into the target engine's own nine-slice or patch-margin controls.

## Preview statement

Store mockups may show example labels, character silhouettes, backgrounds, inventory icons, status icons, or enemy-intent icons. Those preview-only elements are not included unless listed in `CATALOG.csv`.

## License

See `LICENSE.txt`. One lawful acquisition covers one purchasing individual or legal entity and permits any number of personal or commercial End Products. Source-component resale, redistribution, public-repository sharing, standalone NFT/token-image use, and AI-training use are prohibited unless separately permitted in writing.
