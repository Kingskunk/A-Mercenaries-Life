# Changelog

## v1.0 — 2026-09-01

- Initial release package
- Added 12 text-free transparent UI components at 2x and 1x
- Added nine-slice metadata, design tokens, catalog data, gallery, usage guide, license, and disclosure
