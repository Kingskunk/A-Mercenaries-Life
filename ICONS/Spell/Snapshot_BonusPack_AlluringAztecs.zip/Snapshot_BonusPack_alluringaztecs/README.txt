Snapshot Bonus Content Pack

This archive contains only bonus content assets and a configuration file for Snapshot.
No executable files are included.

How to Install

1. Install the latest version of Snapshot. (Either on Windows or on Android)
2. Download the zip file to common place, like your system's Download folder
3. Open the Bonus Content dialog in the game and use the "Import Packages" button
4. Select the zip file of the pack you want to add to the game

Notes
- Bonus Content Packs cannot run on their own. You need Snapshot installed.
- You can install multiple packs at the same time.
- Removing a pack does not damage your save data.

Need Help?
Visit the official Snapshot Discord:
https://discord.com/invite/KtRr4WSyks